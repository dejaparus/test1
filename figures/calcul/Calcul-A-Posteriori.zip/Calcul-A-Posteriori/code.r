###########################################################################################################
# Nicolas BOUSQUET, EDF Recherche et D�veloppement, 2010.
#---------------------------------------------------------
#
#       APPLICATION  DE DIVERSES METHODES DE SIMULATION A POSTERIORI
#
#
#
#
#                  Donn�es X (d�bit de rivi�re) ~ Loi de GUMBEL (mu,lambda)
#
#                  A priori sur (mu,lambda) = m�lange de lois Gamma
#                                             d'hyperparam�tres (m,alpha,xe.alpha)
#                                             o� :
#                                                 m        = taille d'�chantillon fictif (force de l'expertise)
#                                                 xe.alpha = quantile pr�dictif (sur X, donc positif) a priori de seuil alpha (donn� par l'expert)
#                                                 alpha    = seuil de xe.alpha, compris dans [0,1]  (donn� par l'expert)
#                                                 lambda.e = moyenne a priori de lambda (donn�e par l'expert)
#
############################################################################################################
options(warn=(-1))

#===============================================================================#
#
#      JEU DE DONNEES (30 MESURES DE DEBITS)
#
#===============================================================================#

donnees.debit <- c(1306, 1235, 1830, 2442, 1128, 3330, 1530, 3192, 2647, 238,  
                   706, 1903, 1594,  935, 1100, 2204, 1366, 1629,  522,  642, 1173, 
                   424, 1837, 1391, 789,  383, 1858, 917, 1084, 1026)














#===============================================================================#
#
#              Algorithme de Metropolis-Hastings-within-Gibbs 
#
#         N         = nombre de tirages d�sir�s a posteriori
#         burn.in   = nombre de tirages avant pseudo-convergence
#         nb.chains = nombre de cha�nes en parall�le
#         
#        option     =  1    : tirage instrumental dans la loi a priori 
#        option     = 2     : tirage dans une loi normale de coefficient 
#                             de variation 25% et de moyenne la valeur pr�c�dente dans la cha�ne
#        option     = 3     : tirage dans une loi normale de coefficient 
#                             de variation 5% et de moyenne la valeur pr�c�dente dans la cha�ne
#
#        pause      = vecteur des indicateurs des it�rations o� faire une pause
#
#        xlim1, ylim1 = bornes de la fen�tre graphique tra�ant le parcours des simulations dans l'espace bi-dimensionnel
#
#===============================================================================#

MCMC.MH.w.G <- function(option=1,N=1000,burn.in=5000,nb.chains=3,m=0.01,xe.alpha=2000,alpha=0.5,lambda.e=0.00164,donnees=donnees.debit,pause=c(1:100),xlim1=c(3,8.5),ylim1=c(0.0008,0.0018),plotting=c(1:9))
{
  


 
 
  # log-densit� a priori (loi a priori sur lambda)
  log.prior.df <- function(lambda){return(m*(log(m) - log(lambda.e)) - lgamma(m) + (m-1)*log(lambda) - m*lambda/lambda.e)}
 
  # densit� a priori (loi a priori inconditionnelle sur mu) 
  prior.mu <-  r.prior(10000,m,xe.alpha,alpha,lambda.e)$mu 
  prior.dmu <- density(prior.mu[!is.na(prior.mu)],kernel="epanechnikov")
 
  # log-densit� � simuler (loi a posteriori sur lambda)
  log.posterior.df <- function(lambda){log.dens.post.lambda(lambda,m,xe.alpha,alpha,lambda.e,donnees,c())}
   
     
  # log-densit� / tirage instrumentaux
  instr   <- tirage.instrumental.MCMC(nb.chains,option,m,xe.alpha,alpha,lambda.e,donnees)
  log.dg  <- instr$log.dg
  rg      <- instr$rg
  
  
  # initialisation au hasard entre 0 et 1.5*lambda(MLE)
  MLE <- MLE.Gumbel(donnees,plotting=FALSE) 
  lambda.old <- runif(nb.chains,0,(1.5*MLE$lambda))
  chains.lambda <- lambda.old
  chains.mu     <- r.posterior.mu(nb.chains,lambda.old,m,xe.alpha,alpha,lambda.e,donnees,c())
  vals.succ.chain.1 <- test.succ.chain.1 <- taux.acc <- acc <- ref <- val.acc <- val.ref <- lambda.rejet <- mu.rejet <- c()
  GB.stat = NA
 
 
  # repr�sentation jointe des lignes de niveaux de la densit� a posteriori
   min.x = 0
   max.x = 0.004
   mu     = seq(0.8,9,length=100)
   lambda = seq(min.x,max.x,length=100)
   dens.post.joint <- function(mu,lambda){exp(log.dens.posterior(mu,lambda,m,xe.alpha,alpha,lambda.e,donnees,c()))}
   z <- outer(mu,lambda,dens.post.joint)
 
 
   #======= Repr�sentations graphiques statiques/progressives ============================#
   if (length(plotting)==9)
     {
      layout(matrix(c(1:9),3,3))
      layout.show(9)
     }
    if (length(plotting)==1)
     {
      layout(matrix(1,1,1));layout.show(1)
      if (any(plotting==6))
       { 
        contour(mu,lambda,z,nlevels=10,xlab="mu",ylab="lambda",main="",drawlabels=FALSE,xlim=xlim1,ylim=ylim1) 
       }
     }

 
 
 
  #----------------------------------------------------------------#
  #               BOUCLE MCMC                                      # 
  #----------------------------------------------------------------#
  k=1
  while(TRUE)
  {
    k=k+1
    
    #================== ETAPE DE METROPOLIS-HASTINGS ===========================#
    
    # simulation instrumentale en parall�le 
    tirage      <- rg(1,lambda.old)                                                 
  
    # calcul du logarithme du rapport de Metropolis - Hastings
    log.rapport <- log.posterior.df(tirage) -  log.posterior.df(lambda.old) + log.dg(lambda.old,tirage) - log.dg(tirage,lambda.old) 
   
    # calcul du log de la probabilit� moyenne d'acceptation (en traitant les probl�mes num�riques �ventuellement rencontr�s)
    log.prob.accept <- min(0,log.rapport,na.rm=TRUE)
  
    # mise en oeuvre du test parall�lis�
    U          <- runif(nb.chains)
    test       <- (log(U) <= log.prob.accept)
    
    # acceptation ou conservation des anciens tirages
    chains.lambda     <- rbind(chains.lambda,lambda.old)
    chains.lambda[k,test] = tirage[test]
   
   
    
    # calcul du taux d'acceptation effectif en moyenne sur les cha�nes
    taux.acc  <- c(taux.acc,(sum(test,na.rm=TRUE)/nb.chains))
   
   
    # valeur de la densite a posteriori de lambda en les points simul�s
     val.post.simul <- exp(log.posterior.df(tirage)) 
     acc            <- c(acc,tirage[test])
     ref            <- c(ref,tirage[!test])  
     val.acc        <- c(val.acc,val.post.simul[test])
     val.ref        <- c(val.ref,val.post.simul[!test])
   
   
    # estimation autocorrelation des chaines sur lambda
     lags          <- c(2:30)
     if (k>2*max(lags))
      {
        autocor.lambda <- rep(0,length(lags))
        for (l in c(1:length(lags)))
         {
           var.lambda  <- var(as.double(chains.lambda),na.rm=TRUE)
           mean.lambda <- mean(as.double(chains.lambda),na.rm=TRUE)  
           autocor.lambda[l]  <- median(apply( ((chains.lambda[c(1:(k-lags[l])),]-mean.lambda)*(chains.lambda[c((lags[l]+1):k),]-mean.lambda))/var.lambda , 2 , mean , na.rm=TRUE),na.rm=TRUE)
         }
      }   
    
  
   
    #=============== ETAPE DE GIBBS ============================================#
   
    # simulation a posteriori conditionnellement � lambda
    chains.mu <- rbind(chains.mu,r.posterior.mu(nb.chains,chains.lambda[k,],m,xe.alpha,alpha,lambda.e,donnees,c()))
    
    # simulation a posteriori rejet�e 
    if (sum(!test)>0)
     {
       lambda.rejet <- rbind(lambda.rejet,tirage[!test])
       mu.rejet.loc <- r.posterior.mu(nb.chains,tirage[!test],m,xe.alpha,alpha,lambda.e,donnees,c())
       mu.rejet     <- rbind(mu.rejet,mu.rejet.loc)
     }
     
    # densit� a posteriori (inconditionnelle sur mu) 
    posterior.dmu <- density(r.posterior.mu(1000,chains.lambda[k,],m,xe.alpha,alpha,lambda.e,donnees,c()),kernel="epanechnikov")
   
    # conservation des tirages successifs (cha�ne 1) accept�s ou refus�s
    if (test[1]){vals.succ.chain.1     <- rbind(vals.succ.chain.1,c(chains.mu[k,1],tirage[1]))}
    if (!test[1]){vals.succ.chain.1     <- rbind(vals.succ.chain.1,c(mu.rejet.loc[1],tirage[1]))}
    test.succ.chain.1 <- c(test.succ.chain.1,test[1])
    
    
     # Calcul statistique Brooks-Gelman jointe sur (lambda,beta) � partir de 50 it�rations
     GB.stat.prov <- NA
     if (k>50){GB.stat.prov <- Brooks.Gelman(t(chains.lambda),k,nb.chains=nb.chains)}
     GB.stat <- c(GB.stat,GB.stat.prov)
   
   
   
   
   
    #==============  Repr�sentations graphiques progressives ==================#
     # Fenetre 1 
     if (any(plotting==1))
     {log.instrumentale <- function(x){log.dg(x,lambda.old[1])}
      curve(exp(log.instrumentale(x)),xlab="lambda",ylab="",xlim=c(min.x,max.x),col=2,lty=2,lwd=2,)
      curve(exp(log.prior.df(x)),col=1,lwd=2,xlab="lambda",ylab="",main="",add=TRUE)
      title("densit� a priori lambda (noire) / densit� instrumentale (rouge)",cex=0.85)
     }
     

     
    # Fenetre 2  
    if (any(plotting==2))
    {
    for (j in c(1:nb.chains))
     {
      plot(c(1:k),chains.lambda[,j],"l",lwd=2,col=j,xlab="nb.iterations",ylab="lambda",main="",ylim=c(0,max(chains.lambda,na.rm=TRUE)),xlim=c(0,k))
      if (j<nb.chains){par(new=TRUE)}
     }
     title("parcours cha�nes MCMC (lambda)",cex=0.85) 
    }
        
   # Fenetre 3
   if (any(plotting==3))
    {
     f.post <- function(x){exp(log.posterior.df(x))}
     curve(f.post(x),xlim=c(min.x,max.x),col=2,xlab="lambda",ylab="",main="")
     points(acc,val.acc,col=4,lwd=2,add=TRUE)
     title("densit� a posteriori (lambda) / coeff.multiplicatif pres",cex=0.85)
   }
     
     
   # Fenetre 4
   if (any(plotting==4))
    {
     yo=c(0,1.2*max(c(prior.dmu$y,posterior.dmu$y),na.rm=TRUE))
     plot(prior.dmu,col=1,lwd=2,xlab="mu",ylab="",main="",ylim=yo,xlim=c(0,20)) 
     par(new=TRUE)
     plot(posterior.dmu,col=4,lwd=2,lty=1,xlab="mu",ylab="",main="",ylim=yo,xlim=c(0,20))  
     title("densit�s a priori (noire) et a posteriori approx. (bleue)",cex=0.85)
    }
    
  # Fenetre 5  
    if (any(plotting==5))
      {for (j in c(1:nb.chains))
       {
        plot(c(1:k),chains.mu[,j],"l",lwd=2,col=j,xlab="nb.iterations",ylab="mu",main="",ylim=c(0,max(chains.mu,na.rm=TRUE)),xlim=c(0,k))
        if (j<nb.chains){par(new=TRUE)}
       }
      title("parcours cha�nes MCMC (mu)",cex=0.85) 
     }
 
 # Fenetre 6 : repr�sentation du parcours 2-D de la premi�re chaine 
if (any(plotting==6))
 {
  if (length(plotting)>1){contour(mu,lambda,z,nlevels=10,xlab="mu",ylab="lambda",main="",drawlabels=FALSE,xlim=xlim1,ylim=ylim1)}
  {if (k<=7)
   {  
     points(vals.succ.chain.1[test.succ.chain.1,],pch=3,col=4,lwd=2,add=TRUE)
     points(vals.succ.chain.1[!test.succ.chain.1,],pch=4,col=2,lwd=2,add=TRUE)
     lines(vals.succ.chain.1,add=TRUE)  
     
     #points(chains.mu[,1],chains.lambda[,1],pch=3,col=4,add=TRUE)
     #lines(chains.mu[,1],chains.lambda[,1],col=4,add=TRUE)
   }
   else 
   {
     if (((k%%5)==0)&(length(plotting)==1)){contour(mu,lambda,z,nlevels=10,xlab="mu",ylab="lambda",main="",drawlabels=FALSE,xlim=xlim1,ylim=ylim1)}
     indic = test.succ.chain.1[c((k-5):(k-1))]
     vals.succ.chain.1.prog = vals.succ.chain.1[c((k-5):(k-1)),] 
     points(vals.succ.chain.1.prog[indic,],pch=3,col=4,lwd=2,add=TRUE)
     points(vals.succ.chain.1.prog[!indic,],pch=4,col=2,lwd=2,add=TRUE) 
     
     points(vals.succ.chain.1[test.succ.chain.1,],pch=3,col=4,lwd=2,add=TRUE)
     points(vals.succ.chain.1[!test.succ.chain.1,],pch=4,col=2,lwd=2,add=TRUE)
     lines(vals.succ.chain.1[c((k-5):(k-1)),],add=TRUE)   
     #points(chains.mu[c((k-15):k),1],chains.lambda[c((k-15):k),1],pch=3,col=4,add=TRUE)
     #lines(chains.mu[c((k-15):k),1],chains.lambda[c((k-15):k),1],col=4,add=TRUE)
   }
  }  
  title("parcours de la cha�ne 1 (rouge = refuse, bleu = accepte)",cex=0.85) 
  }   
   
   
   # Fenetre 7
  if (any(plotting==7))
  {
   plot(c(1:k),(cumsum(c(taux.acc[1],taux.acc))/c(1:k)),"l",lwd=2,xlab="nb.iterations",ylab="",main="")
   title("taux d'acceptation moyen des cha�nes",cex=0.85)
  }  
   
   # Fenetre 8
  if (any(plotting==8))
  { 
   GB.stat[is.infinite(GB.stat)]=NA
   if (any(!is.na(GB.stat)))
    {
      
      plot(c(1:k),GB.stat,"l",ylim=c(0.5,4),lwd=2,xlab="nb.iterations",ylab="",main="")
    }
   else 
    { 
     plot(c(1:k),rep(0,k),"n",ylim=c(0.5,4),xlab="nb.iterations",ylab="",main="")
    }
   title("statistique de convergence de Brooks-Gelman",cex=0.85) 
  } 
   
   # Fenetre 9
  if (any(plotting==9))
  { 
   if (exists("autocor.lambda"))
   {
     plot(lags,autocor.lambda,"l",lwd=2,xlab="�cart (nb. iter) entre les tirages",main="")
     title("autocorr�lation des cha�nes (lambda)",cex=0.85) 
   }
   else {plot(0,0,"n",axes=FALSE,ylab="",main="",xlab="")}
  } 
   
   
  


 
  
 
  
   # Gestion des pauses du programme 
   if ((length(pause)>0)&(sum(pause==k)==1)){print("Appuyez sur ENTREE pour continuer");browser()}
  
   
   # Remise � jour du tirage courant
   lambda.old = chains.lambda[k,]
   
  if (k==(burn.in+N)){break}                      # on sort de la boucle apr�s les deux phases de burn-in et de stagnation dans le posterior
  } 
  

  return(list("lambda"=chains.lambda,"mu"=chains.mu))
}




#===============================================================================#
#
#                 Statistique de Brooks-Gelman
#                 calcul�e sur un nombre nb.chains
#                 de chaines MCMC parall�les pour
#                 le param�tre theta (matrix nbchains X Nsim)
#
#
#===============================================================================#

Brooks.Gelman  <- function(theta, Nsim, nb.chains=3, pro=0.9)
{
delta<-rep(0,nb.chains)

for(j in 1:nb.chains)
    {
    delta[j] <- (quantile(theta[j,(floor(Nsim/2)):Nsim], probs=pro,na.rm=TRUE)-quantile(theta[j,(floor(Nsim/2)):Nsim], probs=1-pro,na.rm=TRUE))
    }

delta.bas <- sum(delta,na.rm=TRUE)/nb.chains
del <- (quantile(theta[,(floor(Nsim/2)):Nsim], probs=pro,na.rm=TRUE)-quantile(theta[,(floor(Nsim/2)):Nsim], probs=1-pro,na.rm=TRUE))

R <- del/delta.bas
return(R)
}







#===============================================================================#
#
#           Estimation rapide du max de vraisemblance de Gumbel sur des donn�es
#                     non censur�es
#                    (via un algorithme de simplexe)
#
#===============================================================================#

MLE.Gumbel <- function(donnees,plotting=TRUE)
{
 # log-vraisemblance n�gative � minimiser
 ftomin <- function(theta)
 {
  mu     = theta[1]
  lambda = theta[2]
  res = -log.vraisemblance(donnees,c(),mu,lambda)
  return(res)
  }
  theta.init <- c(1,1)
  optimization <- constrOptim(theta=theta.init,f=ftomin,grad=NULL,ui=c(1,1),ci=c(0,0),control=list(maxit=1000))
  MLE.param    <- optimization$par 
  MLE          <- list("lambda"=MLE.param[2],"mu"=MLE.param[1])
  
  if (plotting)
  {
   hist(donnees,10,freq=F,xlab="donn�es de d�bit",ylab="densit�",main="Histogramme / densit� de Gumbel estim�e") # floor(sqrt(length(donnees))),freq=F)
   densite <- function(x)
   {
    lambda = MLE.param[2]
    mu     = MLE.param[1]
    res <- exp( log(mu) + log(lambda) - lambda*x - mu*exp(-lambda*x) )
    return(res)
   }
   curve(densite(x),add=T,col=2)  
  }  
  return(MLE)
}


#===============================================================================#
#
#         Log-vraisemblance des donn�es observ�es
#
#         Les donn�es censur�es le sont � droite
#
#          (cette fonction peut prendre 2 vecteurs (mu,lambda) en entr�e)
#===============================================================================#

log.vraisemblance <- function(donnees.non.censurees,donnees.censurees,mu,lambda)
{
  resultat <- 0

  if (length(donnees.non.censurees))
   {
    for (i in c(1:length(donnees.non.censurees)))
     {
      log.densite <-  log(lambda) + log(mu) - lambda*donnees.non.censurees[i]  - mu*exp(-lambda*donnees.non.censurees[i])
      resultat    <- resultat + log.densite
     }
   }

  if (length(donnees.censurees))
   {
     for (i in c(1:length(donnees.censurees)))
     {
      log.survie <-   - mu*exp(-lambda*donnees.censurees[i])
      resultat    <- resultat + log.survie
     }

   }

  return(resultat)
}



#===============================================================================#
#
#  Fonctionnelle donnant l'hyperparam�tre d'�chelle de la loi a priori de mu
#  sachant lambda, m, xe.alpha et alpha
#
#===============================================================================#

forme.mu <- function(lambda,m,xe.alpha,alpha)
{
  return(exp(-lambda*(xe.alpha))/(alpha^(-1/m) - 1))
}




#===============================================================================#
#
#         Log-densit� a priori de (mu,lambda)
#
#===============================================================================#

log.dens.prior <- function(mu,lambda,m,xe.alpha,alpha,lambda.e)
{
  # log-densit� de la loi a priori (gamma) de mu conditionnelle � lambda
  forme <- forme.mu(lambda,m,xe.alpha,alpha)
  log.dens.mu <- m*log(forme) - lgamma(m) + (m-1)*log(mu) - forme*mu

  # log-densit� de la loi a priori (gamma) de lambda
  log.dens.lambda <- m*(log(m) - log(lambda.e)) - lgamma(m) + (m-1)*log(lambda) - m*lambda/lambda.e
  
  return((log.dens.mu + log.dens.lambda))
}

#===============================================================================#
#
#     Statistiques r�sumant l'information apport�e par les donn�es
#
#        lambda peut �tre un vecteur
#===============================================================================#

stat.donnees <- function(lambda,donnees.non.censurees,donnees.censurees)
{
 x.r <- b.rex <- 0
 if (length(donnees.non.censurees)>0)
  {
    x.r <- mean(donnees.non.censurees,na.rm=TRUE)
   for (i in c(1:length(donnees.non.censurees)))
    {
      b.rex <- b.rex + exp(-lambda*donnees.non.censurees[i])
    }
  }
 if (length(donnees.censurees)>0)
  {
   for (i in c(1:length(donnees.censurees)))
    {
      b.rex <- b.rex + exp(-lambda*donnees.censurees[i])
    }
  }
 return(list("x.r"=x.r,"b.rex"=b.rex))
}






#===============================================================================#
#
#         Log-densit� a posteriori de lambda 
#
#===============================================================================#

log.dens.post.lambda <- function(lambda,m,xe.alpha,alpha,lambda.e,donnees.non.censurees,donnees.censurees)
{
  # Information apport�e par les donn�es
  r = length(donnees.non.censurees)
  stat.summary <- stat.donnees(lambda,donnees.non.censurees,donnees.censurees)
  b.rex <- stat.summary$b.rex
  x.rex <- stat.summary$x.r
  
  # Information a priori
  b.prior <- forme.mu(lambda,m,xe.alpha,alpha)
  
  # Statistiques a posteriori
  b.post <- b.prior + b.rex
  x.post <- r*x.rex + m/lambda.e
  # expression du log
  
  res <-   (m+r-1)*log(lambda) - lambda*x.post + m*log(b.prior) - (m+r)*log(b.post)
  #res <- res + 2*lgamma(m+r) - 2*lgamma(m) + m*(log(m/lambda.e) + log(b.prior)) - (m+r)*(log(b.post) + log(x.post))
  #res <- res + m*log(b.prior) - (m+r)*(log(b.post) + log(x.post))
  return(res)
}


#===============================================================================#
#
#         Log-densit� a posteriori de (mu,lambda)  � une constante
#         multiplicative pr�s (donc avec effet additif dans le log)
#
#===============================================================================#

log.dens.posterior <- function(mu,lambda,m,xe.alpha,alpha,lambda.e,donnees.non.censurees,donnees.censurees)
{
  # log-densit�  de la loi a priori de (mu,lambda)
  log.prior <- log.dens.prior(mu,lambda,m,xe.alpha,alpha,lambda.e)
  
  # log-vraisemblance des donn�es
  log.vrais <- log.vraisemblance(donnees.non.censurees,donnees.censurees,mu,lambda)


  return((log.prior + log.vrais))
}

#===============================================================================#
#
#         Simulation conditionnelle de Gibbs de mu sachant lambda a posteriori
#
#===============================================================================#

r.posterior.mu <- function(n,lambda,m,xe.alpha,alpha,lambda.e,donnees.non.censurees,donnees.censurees)
{
    # Information apport�e par les donn�es
    r = length(donnees.non.censurees)
    stat.summary <- stat.donnees(lambda,donnees.non.censurees,donnees.censurees)
    b.rex <- stat.summary$b.rex
   
  
    # Information a priori
    b.prior <- forme.mu(lambda,m,xe.alpha,alpha)
  
    # Statistiques a posteriori
    b.post <- b.prior + b.rex
    
    return(rgamma(n,(m+r),b.post))   
}

#===============================================================================#
#
#     Simulation de (mu,lambda) a priori
#
#===============================================================================#

r.prior <- function(n,m,xe.alpha,alpha,lambda.e)
{
    lambda  <- rgamma(n,m,(m/lambda.e))
    b.prior <- forme.mu(lambda,m,xe.alpha,alpha)
     mu     <- rgamma(n,m,b.prior)
  return(list("lambda"=lambda,"mu"=mu))
}     



#===============================================================================#
#
#    Calcul de la constante K pour l'algorithme d'acceptation-rejet sur LAMBDA
#    = maximisation du rapport dens.posterior/dens.instrumentale
#    lorsque la loi instrumentale
#
#
#===============================================================================#

calcul.constante.AR <- function(m,xe.alpha,alpha,lambda.e,donnees.non.censurees,donnees.censurees,a,b)
{

  # log de la densit� � simuler
  log.f <- function(lambda){log.dens.post.lambda(lambda,m,xe.alpha,alpha,lambda.e,donnees.non.censurees,donnees.censurees)}

  # log de la densit� instrumentale choisie (loi Gamma)
  log.g <- function(lambda){a*log(b)-lgamma(a) + (a-1)*log(lambda) - b*lambda}
  
  # Calcul du log de la constante par maximisation de la diff�rence
  ftomin <- function(lambda){- (log.f(lambda)-log.g(lambda))}
  
  
  lambda.sol <- optimize(f=ftomin,lower=0,upper=10)$minimum
  M <- exp(log.f(lambda.sol)-log.g(lambda.sol))

return(M)
}

  
#===============================================================================#
#
#            Fonction permettant de donner la densit� et de simuler 
#                selon une loi instrumentale pour les MCMC
#
#
#===============================================================================#  
  
tirage.instrumental.MCMC <- function(nb.chains,option,m,xe.alpha,alpha,lambda.e,donnees)
{
  #-----------------------------------------------------------------------------
  if (option==1)       # tirage instrumental statique via la loi a priori
  {
    log.dg <- function(x,y)
     {
        return(m*(log(m) - log(lambda.e)) - lgamma(m) + (m-1)*log(x) - m*x/lambda.e)
     }
    rg <- function(n,x)
     {
       return(matrix(rgamma((n*nb.chains),m,(m/lambda.e)),n,nb.chains))
     }
  }
  
  
  #-----------------------------------------------------------------------------
  if (option==2)       # loi normale en la derni�re valeur observ�e, de coefficient de variation 25%
  {
   coeff.variation = 0.25
    log.dg <- function(x,y)
     {   
        sigma <- coeff.variation*y
        return(-0.5*log(2*pi) - log(sigma) - (x-y)^2/(2*(sigma^2)))
     }
    rg <- function(n,x)
     {
       sigma <- coeff.variation*x
       return(matrix(rnorm((n*nb.chains),x,sigma),n,nb.chains))
     }
  }  

  #-----------------------------------------------------------------------------
  if (option==3)       # loi normale en la derni�re valeur observ�e, de coefficient de variation 5%
  {
   coeff.variation = 0.05
    log.dg <- function(x,y)
     {   
        sigma <- coeff.variation*y
        return(-0.5*log(2*pi) - log(sigma) - (x-y)^2/(2*(sigma^2)))
     }
    rg <- function(n,x)
     {
       sigma <- coeff.variation*x
       return(matrix(rnorm((n*nb.chains),x,sigma),n,nb.chains))
     }
  } 

 return(list("log.dg"=log.dg,"rg"=rg))
} 













#===============================================================================#
#
#     150 donn�es de d�bit simul�es (provenant d'Alberto Pasanisi)
#
#
#===============================================================================#

donnees.debit.simulees <- c(3854,
3361,
3330,
3320,
3224,
3192,
3044,
2706,
2647,
2595,
2491,
2442,
2435,
2417,
2204,
2151,
2090,
2078,
2037,
2017,
1991,
1958,
1924,
1920,
1909,
1906,
1903,
1889,
1858,
1839,
1837,
1837,
1830,
1792,
1771,
1730,
1711,
1695,
1649,
1629,
1605,
1594,
1575,
1556,
1543,
1530,
1528,
1526,
1525,
1515,
1512,
1512,
1511,
1462,
1454,
1433,
1433,
1421,
1400,
1391,
1383,
1377,
1368,
1366,
1359,
1348,
1348,
1334,
1331,
1307,
1306,
1283,
1275,
1260,
1256,
1255,
1248,
1235,
1230,
1227,
1173,
1169,
1153,
1149,
1149,
1148,
1128,
1127,
1125,
1100,
1084,
1073,
1048,
1036,
1035,
1026,
971,
965,
956,
935,
917,
903,
891,
885,
881,
868,
856,
856,
846,
843,
811,
800,
793,
789,
771,
766,
759,
758,
740,
733,
733,
731,
714,
706,
704,
703,
669,
651,
642,
635,
630,
619,
582,
547,
541,
523,
522,
493,
424,
383,
378,
352,
351,
341,
331,
238,
227,
136,
122
)  
   
